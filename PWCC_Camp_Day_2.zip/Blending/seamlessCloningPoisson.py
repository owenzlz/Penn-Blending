'''
  File name: seamlessCloningPoisson.py
  Author:
  Date created:
'''
import numpy as np
import getIndexes
import getCoefficientMatrix
import getSolutionVect
import reconstructImg

def seamlessCloningPoisson(sourceImg, targetImg, mask, offsetX, offsetY):
  debug = 0
  
  indexes = getIndexes.getIndexes(mask, targetImg.shape[0], targetImg.shape[1], offsetX, offsetY)
  coeffA = getCoefficientMatrix.getCoefficientMatrix(indexes)
  coeffA = coeffA.astype(np.float64)
  red   = getSolutionVect.getSolutionVect(indexes,sourceImg[:,:,0],targetImg[:,:,0],offsetX,offsetY)
  green = getSolutionVect.getSolutionVect(indexes,sourceImg[:,:,1],targetImg[:,:,1],offsetX,offsetY)
  blue  = getSolutionVect.getSolutionVect(indexes,sourceImg[:,:,2],targetImg[:,:,2],offsetX,offsetY)
  
  x_r = np.linalg.solve(coeffA, red)
  x_g = np.linalg.solve(coeffA, green)
  x_b = np.linalg.solve(coeffA, blue)
  
  if debug:
#      print "x_r, x_g, x_b"
#      print x_r, x_g, x_b
#      print x_r.shape, x_b.shape, x_g.shape
      np.savetxt('x_r.txt',x_r)
      np.savetxt('x_g.txt',x_g)
      np.savetxt('x_b.txt',x_b)
      
      x_r = np.loadtxt('x_r.txt')
      x_g = np.loadtxt('x_g.txt')
      x_b = np.loadtxt('x_b.txt')
#      print x_r.min(), x_r.max()
#      print x_g.min(), x_g.max()
#      print x_b.min(), x_b.max()
  
  resultImg = reconstructImg.reconstructImg(indexes, x_r, x_g, x_b, targetImg)
  
  return resultImg

