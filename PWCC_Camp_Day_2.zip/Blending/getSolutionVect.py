'''
  File name: getSolutionVect.py
  Author:
  Date created:
'''

from scipy import signal
import numpy as np

def getSolutionVect(indexes, source, target, offsetX, offsetY):
    debug = 0
    
    source_h, source_w = source.shape
    targetH, targetW = target.shape
    
    source = np.c_[np.zeros((source_h, offsetY)),source]                        #add zeros columns to the left of mask
    source = np.c_[source,np.zeros((source_h,targetW - offsetY - source_w))]    #add zeros columns to the right of mask
    source = np.r_[np.zeros((offsetX,targetW)),source]                          #add zeros rows to the top of mask
    source = np.r_[source,np.zeros((targetH - offsetX - source_h,targetW))]     #add zeros rows to the bottom of mask
    
    lap = np.asarray([[0.0,-1.0,0.0],[-1.0,4.0,-1.0],[0.0,-1.0,0.0]])
    source_lap = signal.convolve2d(source, lap, mode='same')
    
    if debug:
        print("source_lap.shape")
        print(source_lap.shape)
        print(source_lap[108,144])
    
    indexes_h, indexes_w = indexes.shape
    pos = np.zeros([1,2])
    
    for j in range(indexes_h):
        for k in range(indexes_w):
            if indexes[j,k] == 1:
                a = np.array([j,k]).reshape([1,2])
                pos = np.r_[pos,a]
                
    pos = np.delete(pos,0,axis=0)
    pos = pos.astype(int)

    N = indexes.sum()
    N = int(N)
    SolVectorb = np.zeros((N,1))
    
    for i in range(N):
        x = pos[i,0]
        y = pos[i,1]
        if indexes[x+1, y] == 1:
            SolVectorb[i] = SolVectorb[i] + source_lap[x,y]
        elif indexes[x+1, y] == 0:
            SolVectorb[i] = SolVectorb[i] + source_lap[x,y] + target[x+1, y]
        else:
            print("error***************************")
            
        if indexes[x-1, y] == 1:
            SolVectorb[i] = SolVectorb[i] + source_lap[x,y]
        elif indexes[x-1, y] == 0:
            SolVectorb[i] = SolVectorb[i] + source_lap[x,y] + target[x-1, y]
        else:
            print("error***************************")
            
        if indexes[x, y+1] == 1:
            SolVectorb[i] = SolVectorb[i] + source_lap[x,y]
        elif indexes[x, y+1] == 0:
            SolVectorb[i] = SolVectorb[i] + source_lap[x,y] + target[x, y+1]
        else:
            print("error***************************") 
                    
        if indexes[x, y-1] == 1:
            SolVectorb[i] = SolVectorb[i] + source_lap[x,y]
        elif indexes[x, y-1] == 0:
            SolVectorb[i] = SolVectorb[i] + source_lap[x,y] + target[x, y-1]
        else:
            print("error***************************")
    
    if debug:
        print("\nSolVectorb:")
        print(SolVectorb, SolVectorb.shape)
        np.savetxt('SolVectorb.txt',SolVectorb)
    
    return SolVectorb
