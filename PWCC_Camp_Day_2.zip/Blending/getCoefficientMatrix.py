'''
  File name: getCoefficientMatrix.py
  Author:
  Date created:
'''
import numpy as np

def getCoefficientMatrix(indexes):
    debug = 0
    
    indexes_h, indexes_w = indexes.shape
    pos = np.zeros([1,2])
    
    for j in range(indexes_h):
        for k in range(indexes_w):
            if indexes[j,k] == 1:
                a = np.array([j,k]).reshape([1,2])
                pos = np.r_[pos,a]
                
    pos = np.delete(pos,0,axis=0)
    pos = pos.astype(int)

    N = indexes.sum()
    N = int(N)
    coeffA = np.zeros((N,N))
        
    for i in range(N):
        coeffA[i,i] = 4
        
        if indexes[pos[i,0]+1, pos[i,1]] == 1:
            for j,k in enumerate(pos):
                if k[0] == pos[i,0]+1 and k[1] == pos[i,1]:
                    coeffA[i,j] = -1
                    
        if indexes[pos[i,0]-1, pos[i,1]] == 1:
            for j,k in enumerate(pos):
                if k[0] == pos[i,0]-1 and k[1] == pos[i,1]:
                    coeffA[i,j] = -1
                    
        if indexes[pos[i,0], pos[i,1]+1] == 1:
            for j,k in enumerate(pos):
                if k[0] == pos[i,0] and k[1] == pos[i,1]+1:
                    coeffA[i,j] = -1
                    
        if indexes[pos[i,0], pos[i,1]-1] == 1:
            for j,k in enumerate(pos):
                if k[0] == pos[i,0] and k[1] == pos[i,1]-1:
                    coeffA[i,j] = -1
                    
    if debug:
        np.savetxt('coeffAsum.txt',np.sum(coeffA, axis=1))
        
    return coeffA
