# -*- coding: utf-8 -*-
"""
Created on Sun Jul 29 12:13:13 2018

@author: Owen
"""

import numpy as np
from PIL import Image
from skimage.io import imsave
import matplotlib.pyplot as plt
import cv2

# Input Configuration
background_img_path = 'background.jpg'
source_img_path = 'obj.jpg'
mask_path = 'mask.txt'
x_start = 400
y_start = 400

# load background image, source image, mask
background_img = np.array(Image.open(background_img_path).convert('RGB'))
mask = np.loadtxt(mask_path)
imsave('mask.jpg', mask)
source_img = np.array(Image.open(source_img_path).convert('RGB'))
source_obj = np.zeros((source_img.shape[0], source_img.shape[1], 3))
for i in range(3):
    source_obj[:,:,i] = source_img[:,:,i]*mask


# create canvas source image and canvas mask
canvas_source_img = np.zeros((background_img.shape))
canvas_source_img[x_start:source_obj.shape[0]+x_start, y_start:source_obj.shape[1]+y_start] = source_obj
canvas_mask = np.zeros((background_img.shape[0], background_img.shape[1]))
canvas_mask[x_start:source_obj.shape[0]+x_start, y_start:source_obj.shape[1]+y_start] = mask


# directly copy and paste
mask_source = canvas_mask
mask_target = np.zeros((mask_source.shape))
for i in range(mask_source.shape[0]):
    for j in range(mask_source.shape[1]):
        if mask_source[i,j] == 0:
            mask_target[i,j] = 1
        else:
            mask_target[i,j] = 0
output_img = np.zeros((background_img.shape))
for i in range(3):
    output_img[:,:,i] = canvas_source_img[:,:,i]*mask_source + background_img[:,:,i]*mask_target
plt.figure()
plt.imshow(output_img/255)
plt.axis('off')
plt.title('copy and paste')

# alpha blending
alpha = 0.5
mask_source_alpha = mask_source*alpha
mask_target_alpha = mask_target*(1-alpha)
output_img = np.zeros((background_img.shape))
for i in range(3):
    output_img[:,:,i] = canvas_source_img[:,:,i]*mask_source_alpha + background_img[:,:,i]*mask_target_alpha
plt.figure()
plt.imshow(output_img/255)
plt.axis('off')
plt.title('alpha blending')

# gradient domain blending
center = (x_start+200, y_start+200)
source = cv2.imread(source_img_path)
mask = cv2.imread('mask.jpg')
target = cv2.imread(background_img_path)
output_img = cv2.seamlessClone(source, target, mask, center, cv2.NORMAL_CLONE)
output_img = cv2.cvtColor(output_img, cv2.COLOR_BGR2RGB)
plt.figure()
plt.imshow(output_img)
plt.axis('off')
plt.title('gradient domain blending')





