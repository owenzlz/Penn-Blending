# -*- coding: utf-8 -*-
"""
Created on Mon Oct 16 23:44:00 2017

@author: kcchi
"""
from PIL import Image

import numpy as np
import matplotlib.pyplot as plt
import seamlessCloningPoisson


def main():
  debug = 0
  
  case = 0
  
  if case == 0:
       # Blending Benjamin and Minion
      im1 = Image.open("SourceImage.png").convert('RGB')
      im2 = Image.open("TargetImage.png").convert('RGB')
      mask = np.loadtxt('mask_minion.txt')
      offsetX = 180
      offsetY = 250
  elif case == 1:
      # Blending Lebron James and Golden State Warrior's Trophy
      im1 = Image.open("lbj.png").convert('RGB')
      im2 = Image.open("trophy.jpg").convert('RGB')
      mask = np.loadtxt('mask_lbj.txt')
      offsetX = 5
      offsetY = 100
  
  im1 = np.array(im1)
  im2 = np.array(im2)
  im1 = im1.astype(np.float64)
  im2 = im2.astype(np.float64)
  mask = np.array(mask)
  
  resultImg = seamlessCloningPoisson.seamlessCloningPoisson(im1, im2, mask, offsetX, offsetY)
  
  plt.figure()
  plt.imshow(resultImg)
  
if __name__ == "__main__":
  main()




