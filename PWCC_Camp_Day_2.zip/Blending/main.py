#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Tue Aug  7 21:58:47 2018

@author: owen
"""

import numpy as np
import getIndexes
import getCoefficientMatrix
import getSolutionVect
import reconstructImg
from PIL import Image
import numpy as np
import matplotlib.pyplot as plt
import seamlessCloningPoisson

# Define source image, source mask, target image, and blending location x, y
im1 = Image.open("SourceImage.png").convert('RGB')
im2 = Image.open("TargetImage.png").convert('RGB')
mask = np.loadtxt('mask_minion.txt')
offsetX = 180
offsetY = 250

# preprocess images
im1 = np.array(im1)
im2 = np.array(im2)
im1 = im1.astype(np.float64)
im2 = im2.astype(np.float64)
mask = np.array(mask)



plt.figure()
plt.imshow(im1/255)
plt.title('source image')

plt.figure()
plt.imshow(mask/255)
plt.title('source image mask')

plt.figure()
plt.imshow(im2/255)
plt.title('target image')

# find out indexing for each reconstructed pixels
indexes = getIndexes.getIndexes(mask, targetImg.shape[0], targetImg.shape[1], offsetX, offsetY)

# compute coefficient matrix
coeffA = getCoefficientMatrix.getCoefficientMatrix(indexes)
coeffA = coeffA.astype(np.float64)

# compute solution vector
red   = getSolutionVect.getSolutionVect(indexes,sourceImg[:,:,0],targetImg[:,:,0],offsetX,offsetY)
green = getSolutionVect.getSolutionVect(indexes,sourceImg[:,:,1],targetImg[:,:,1],offsetX,offsetY)
blue  = getSolutionVect.getSolutionVect(indexes,sourceImg[:,:,2],targetImg[:,:,2],offsetX,offsetY)
  
# compute reconstructed pixels in all RGB channels 
x_r = np.linalg.solve(coeffA, red)
x_g = np.linalg.solve(coeffA, green)
x_b = np.linalg.solve(coeffA, blue)

# combine the reconstructed pixels into the target image
resultImg = reconstructImg.reconstructImg(indexes, x_r, x_g, x_b, targetImg)



# visualize blending image results
plt.figure()
plt.imshow(resultImg[:,:,0])
plt.title('Image Blending Results in Red Channel')

plt.figure()
plt.imshow(resultImg[:,:,1])
plt.title('Image Blending Results in Green Channel')

plt.figure()
plt.imshow(resultImg[:,:,2])
plt.title('Image Blending Results in Blue Channel')

plt.figure()
plt.imshow(resultImg)
plt.title('Image Blending Results in RGB')




