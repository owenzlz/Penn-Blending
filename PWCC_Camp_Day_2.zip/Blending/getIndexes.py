'''
  File name: getIndexes.py
  Author:
  Date created:
'''
import numpy as np

def getIndexes(mask, targetH, targetW, offsetX, offsetY):
    mask_h, mask_w = mask.shape
    
    indexes = np.c_[np.zeros((mask_h, offsetY)),mask]                       #add zeros columns to the left of mask
    indexes = np.c_[indexes,np.zeros((mask_h,targetW - offsetY - mask_w))]  #add zeros columns to the right of mask
    indexes = np.r_[np.zeros((offsetX,targetW)),indexes]                    #add zeros rows to the top of mask
    indexes = np.r_[indexes,np.zeros((targetH - offsetX - mask_h,targetW))] #add zeros rows to the bottom of mask
    
    return indexes