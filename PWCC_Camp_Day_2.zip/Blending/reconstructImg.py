'''
  File name: reconstructImg.py
  Author:
  Date created:
'''
import numpy as np

def reconstructImg(indexes, red, green, blue, targetImg):
    debug = 0
    
    indexes_h, indexes_w = indexes.shape
    indexes_inv = -1*(indexes - 1)
    patch = np.zeros([indexes_h,indexes_w,3])
    targetImg_inv = np.zeros([indexes_h,indexes_w,3])
    i = 0
    for j in range(indexes_h):
        for k in range(indexes_w):
            if indexes[j,k] == 1:
                patch[j,k,0] = (red[i])
                patch[j,k,1] = (green[i])
                patch[j,k,2] = (blue[i])
                i+=1
                
#    patch= 255.0 * (((patch - patch.min()) / (patch.max() - patch.min())))
    patch = np.clip(patch,0,255)
    
    patch[:,:,0] = np.multiply(patch[:,:,0],indexes)
    patch[:,:,1] = np.multiply(patch[:,:,1],indexes)
    patch[:,:,2] = np.multiply(patch[:,:,2],indexes)
    
    targetImg_inv[:,:,0] = np.multiply(targetImg[:,:,0],indexes_inv)
    targetImg_inv[:,:,1] = np.multiply(targetImg[:,:,1],indexes_inv)
    targetImg_inv[:,:,2] = np.multiply(targetImg[:,:,2],indexes_inv)
    resultImg = (targetImg_inv + patch)/255.0
    
    if debug:
        print("targetImg_inv[:,:,0], patch[:,:,0], resultImg[:,:,0]")
        print(targetImg_inv[:,:,0], patch[:,:,0], resultImg[:,:,0])
        print(indexes)
        print(indexes_inv)
        
        np.savetxt('patch_r.txt',patch[:,:,0])
        np.savetxt('red.txt',red)
        np.savetxt('green.txt',green)
        np.savetxt('blue.txt',blue)
            
    return resultImg