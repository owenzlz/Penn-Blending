# -*- coding: utf-8 -*-
"""
Created on Tue Oct 17 19:28:13 2017

@author: kcchi
"""

from drawMask import draw_mask
import numpy as np
import matplotlib
import matplotlib.pyplot as plt
import maskImage
import getIndexes
import getCoefficientMatrix
import getSolutionVect
import seamlessCloningPoisson
import reconstructImg
import scipy.sparse.linalg as scilinalg
import scipy
from PIL import Image
from skimage.io import imsave

def main():
    image_file = "SourceImage.png"
    
    img = Image.open(image_file).convert('RGB').resize((100,100))
#    print(img.size)
    imsave(image_file, img)
    
    img = np.array(img)
    output_name = 'source_object'
    mask = maskImage.maskImage(img, output_name)

if __name__ == "__main__":
	main()
  


