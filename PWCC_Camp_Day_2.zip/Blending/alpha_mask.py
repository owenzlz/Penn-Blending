#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""
Created on Sat Aug 11 23:26:58 2018

@author: owen
"""
import numpy as np
from PIL import Image
from skimage.io import imsave
import matplotlib.pyplot as plt
import cv2

x_start = 180
y_start = 250

background_img_path = "TargetImage.png"
source_img_path = "SourceImage.png"
background_img = np.array(Image.open(background_img_path).convert('RGB'))
source_img = np.array(Image.open(source_img_path).convert('RGB'))

num_mask = 5

alpha_mask = np.zeros((source_img.shape[0], source_img.shape[1]))
for i in range(num_mask):
    mask = np.loadtxt('mask_'+str(i)+'.txt')
    alpha_mask = alpha_mask + mask
alpha_mask = alpha_mask/num_mask

#plt.figure()
#plt.imshow(alpha_mask)

source_img = np.array(Image.open(source_img_path).convert('RGB'))
source_obj = np.zeros((source_img.shape[0], source_img.shape[1], 3))
for i in range(3):
    source_obj[:,:,i] = source_img[:,:,i]*alpha_mask 


# create canvas source image and canvas mask
canvas_source_img = np.zeros((background_img.shape))
canvas_source_img[x_start:source_obj.shape[0]+x_start, y_start:source_obj.shape[1]+y_start] = source_obj
canvas_mask = np.zeros((background_img.shape[0], background_img.shape[1]))
canvas_mask[x_start:source_obj.shape[0]+x_start, y_start:source_obj.shape[1]+y_start] = alpha_mask

plt.figure()
plt.imshow(canvas_mask)

# directly copy and paste
mask_source = canvas_mask
mask_target = np.zeros((mask_source.shape))
for i in range(mask_source.shape[0]):
    for j in range(mask_source.shape[1]):
#        if mask_source[i,j] == 0:
#            mask_target[i,j] = 1
#        else:
#            mask_target[i,j] = 0
        mask_target[i,j] = 1 - mask_source[i,j]


output_img = np.zeros((background_img.shape))

source_image = canvas_source_img
target_image = background_img
source_mask = mask_source
target_mask = mask_target
    
# TODO: complete the image copy and paste
for i in range(3):
    output_img[:,:,i] = source_image[:,:,i]*source_mask+target_image[:,:,i]*target_mask

plt.figure()
plt.imshow(output_img/255)
plt.axis('off')
plt.title('copy and paste')
imsave('outputs/copy_paste_output.jpg', output_img/255)



# alpha blending
mask_target_inverse = np.zeros((mask_target.shape))
for i in range(mask_target.shape[0]):
    for j in range(mask_target.shape[1]):
        if mask_target[i,j] == 1:
            mask_target_inverse[i,j] = 0
        else:
            mask_target_inverse[i,j] = 1

alpha = 0.9

target_mask_inverse = mask_target_inverse

# TODO: complete the alpha blending
for i in range(3):
    output_img[:,:,i] = source_image[:,:,i]*source_mask*alpha + target_image[:,:,i]*target_mask + target_image[:,:,i]*target_mask_inverse*(1-alpha)

plt.figure()
plt.imshow(output_img/255)
plt.axis('off')
plt.title('alpha blending')
imsave('outputs/alpha_blending.jpg', (output_img/255).astype('uint8'))




